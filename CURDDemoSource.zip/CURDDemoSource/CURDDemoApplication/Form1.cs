﻿using CURDDemo;
using System;
using System.Data;
using System.Windows.Forms;

namespace CURDDemoApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape) this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            BindData();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (btnSave.Text == "Save")
            {
                EmployeeClass obj = new EmployeeClass();
                obj.Name = tbName.Text;
                obj.MobileNo = tbMobileNo.Text;

                MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Insert(obj);

                tbName.Text = tbMobileNo.Text = string.Empty;
                BindData();

                MessageBox.Show(mRes.Outmsg.ToString());
            }
            else if (btnSave.Text == "Update")
            {
                int RecordID = 0;
                int.TryParse(lblID.Text, out RecordID);

                EmployeeClass obj = new EmployeeClass();
                obj.ID = RecordID;
                obj.Name = tbName.Text;
                obj.MobileNo = tbMobileNo.Text;

                MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Update(obj);

                tbName.Text = tbMobileNo.Text = string.Empty;
                BindData();

                MessageBox.Show(mRes.Outmsg.ToString());

                btnSave.Text = "Save";
            }
        }

        private void dgvData_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            string ID = dgvData.SelectedRows[0].Cells["ID"].Value.ToString();
            lblID.Text = ID;

            int RecordID = 0;
            int.TryParse(ID, out RecordID);

            DataTable dt = new EmployeeLogic().Employee_Get(RecordID);

            if (dt.Rows.Count > 0)
            {
                tbName.Text = dt.Rows[0]["Name"].ToString();
                tbMobileNo.Text = dt.Rows[0]["MobileNo"].ToString();

                btnSave.Text = "Update";
            }
        }

        private void dgvData_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                DialogResult dlg = MessageBox.Show("Are you sure you wan't delete this record.", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (dlg == DialogResult.Yes)
                {
                    string ID = dgvData.SelectedRows[0].Cells["ID"].Value.ToString();

                    int RecordID = 0;
                    int.TryParse(ID, out RecordID);

                    MEMBERS.SQLReturnMessageNValue mRes = new EmployeeLogic().Employee_Delete(RecordID);

                    BindData();

                    MessageBox.Show(mRes.Outmsg.ToString());
                }
            }
        }

        public void BindData()
        {
            dgvData.DataSource = new EmployeeLogic().Employee_GetAll();

            dgvData.Columns["ID"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvData.Columns["Name"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dgvData.Columns["MobileNo"].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dgvData.Columns["MobileNo"].HeaderText = "Mobile No";
        }
    }
}
